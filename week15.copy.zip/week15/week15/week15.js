//Задание 1 +
// Выведите числа от 1 до 10 в консоль
/*for (i = 0; i <= 10; i++) {
    //console.log(i);
}*/

//Задание 2 +
// Выведите чётные числа от 1 до 20 в консоль
let number = 0;
while (number <= 20) {
    //console.log(number);
    number += 2;
}

//Задание 3 +
// Выведите числа от 10 до 1 в консоль в обратном порядке
let arrNum = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
//console.log(arrNum.reverse());

//Задание 4 +
// Выведите таблицу умножения на 5 от 1 до 10
/*for (i = 1; i <= 10; i++) {
    console.log(i * 5);
}*/
//Задание 5 +
// Вычислить сумму чисел от 1 до 100 и вывести значение в консоль
let sum = 0;
for (let i = 0; i <= 100; i++) {
    sum += i;
}
//console.log(sum);

//Задание 6 +
// Выведите все элементы массива в консоль используя цикл for
const array = [1, 2, 3, 4, 5];
for (let i = 0; i < array.length; i += 1) {
    //console.log(array[i]);
}


//Задание 7 +
// Выведите сумму всех элементов массива используя цикл for
const numbers = [1, 2, 3, 4, 5];
let summa = 0;
for (i = 0; i < numbers.length; i++) {
    summa += numbers[i];
}
//console.log(summa);


//Задание 8 +
// Напишите цикл for, который изменяет массив животных, делая их прекрасными! Например, если есть следующий массив: let animals = ["Кот", "Рыба", "Лемур"]; цикл должен сделать его таким: ["Кот - прекрасное животное", "Рыба - прекрасное животное", "Лемур - прекрасное животное"]
// Подсказка: вам понадобится переприсвоить значения для каждого индекса, то есть присвоить новые значения уже суще- ствующим элементам: animals[0] = animals[0] + " - прекрасное животное";
let animals = ["Кот", "Рыба", "Лемур"];
for (i = 0; i < animals.length; i++) {
    animals[i] = animals[i] + " - прекрасное животное";

}
//console.log(animals);

//Задание 9 +
// Выведите символы в строке в консоль
const str = 'Hello';
for (let symbol of str) {
    //console.log(symbol);
}

//Задание 10 +
// Выведите все элементы массива в консоль используя цикл for...of. Массив array объявлен в Задании 6
const array1 = [1, 2, 3, 4, 5];
for (number of array1) {
    //console.log(number);
}

//Задание 11 +-
// Выведите каждое слово из массива строк в консоль
// Подсказка: вам понадобится метод массивов split
const sentences = ['Hello, world!', 'How are you?'];
let sentences1 = sentences.join('');
let newSentences = sentences1.split('');
/*for (i = 0; i < newSentences1.length; i++) {
    console.log(newSentences1[i]);
}*/
//console.log(newSentences);

//Задание 12 +
// Выведите сумму всех элементов массива используя цикл for..of. Массив numbers объявлен в Задании 7
const numbers1 = [1, 2, 3, 4, 5];
let sum1 = 0;
for (number of numbers) {
    sum1 += number
}
//console.log(sum1);

//Задание 13 + 
// Выведите длину каждого слова из массива строк в консоль
const list = ['apple', 'banana', 'cherry'];
//console.log(list[0].length);
//console.log(list[1].length);
//console.log(list[2].length);

//Задание 14
// Преобразуйте массив каждый элемент массива words в верхний регистр
const words1 = ['Hello', 'world', '!'];
for (i = 0; i < words1.length; i += 1
) {
    let word = words1[i];
    let upWords = word.toUpperCase;
    words1[i] = upWords;
}
//console.log(words1);

//Задание 15
// Подсчитайте количество гласных букв в строке
// Подсказка: вам понадобится метод includes
const greeting = 'Hello, world!';
let vowelCount = 0;
const vowels = ['a', 'e', 'i', 'o', 'u'];



//Задание 16
// Объедините все строки массива в одну строку с пробелами между ними
const words = ['Hello', 'world', '!'];

//Задание 17 +
// Выведите числа от 1 до 10 в консоль используя цикл while
let numb = 1;
while (numb <= 10) {
    //console.log(numb);
    numb += 1;
}

//Задание 18 +
// Выведите числа от 1 до 10 в консоль в обратном порядке используя цикл while
let numb1 = 10;
while (numb1 >= 1) {
    //console.log(numb1);
    numb1 -= 1;
}

//Задание 19 +
// Проверьте, все ли элементы массива являются положительными числами используя цикл while
// Подсказка: используйте директиву break
const allNumbers = [1, 2, 3, -4, 5];
let allPositive = true;
let a = 0;
for (let number19 of allNumbers) {
    while (allPositive == true) {
        if (number19 < 0) {
            allPositive == false
        }
        break
    }
}
//console.log(allPositive);
//Задание 20 +
// Выведите значения элементов массива до первого отрицательного числа используя цикл do...while
const random = [2, 4, 6, -3, 8, 10];
let b = 0;
do {
    //console.log(random[b]);
    b++;
}
while (random[b] >= 0);

//Задание 21 +
// Выведите числа от 1 до 100, пропуская числа, которые делятся на 3 используя цикл do...while
let c = 1;
/*do {
    if (c % 3 !== 0) {
        console.log(c);
    }
    c++;

}
while (c <= 100);*/

//Задание 22
// Запросить у пользователя числа, пока сумма введенных чисел не станет больше 100
let s = 0;
let n = 0;
do {
    n = Math.floor(Math.random() * 100);
    // console.log(n);
    s += n;
} while (s < 100)

//Задание 23
// Напишите функцию, которая изменит фоновый цвет всех элементов <h4> на странице на синий цвет
let headers = document.querySelectorAll('h4');

for (header of headers) {
    header.style.background = 'blue';
}

//Задание 24 +
// Напишите генератор случайных строк до 6 символов
// Подсказка: используйте методы объекта Math и длину массива alphabet
let alphabet = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя';
let randomString = '';
while (randomString.length < 6) {
    randomString += alphabet[Math.floor(Math.random() * alphabet.length)];
}
//console.log(randomString);